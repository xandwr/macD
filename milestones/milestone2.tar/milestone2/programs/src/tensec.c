#include <stdio.h>
#include <unistd.h>

/// @brief Executes a test program that runs for 10 seconds and exits.
int main() {
    sleep(10);
    return 0;
}
