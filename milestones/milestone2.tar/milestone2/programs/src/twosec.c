#include <stdio.h>
#include <unistd.h>

/// @brief Executes a test program that runs for 2 seconds and exits.
int main() {
    sleep(2);
    return 0;
}
