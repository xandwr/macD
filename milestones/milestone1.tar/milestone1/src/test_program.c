#include <stdio.h>
#include <unistd.h>

/// @brief Executes a test program that runs for 3 seconds and exits.
int main() {
    sleep(3);
    return 0;
}
